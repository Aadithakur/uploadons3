package com.qc.mmm.utils;

public class Constants {
	
	/**** QC-Dev Credentials ****/
	public static final String ACCESS_KEY = "AKIATRAURKYOLAIVTOPA";
	public static final String SECRET_ACCESS_KEY = "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";
	public static final String S3_BUCKET_NAME_PDF = "qc-testing";
	public static final String S3_BUCKET_NAME_LOGS = "qc-testing";
	public static final String PDF_FILE_PATH =  "D:/Document/Dummy/pdfFiles";
	public static final String LOG_FILE_PATH = "D:/Document/Dummy/logFiles";
	
	
	/**** Client-Credentials ****/
//	public static final String ACCESS_KEY = "AKIAYQBE645X4AXCZXEP";
//	public static final String SECRET_ACCESS_KEY = "oFP3D6pQpV5L02yE/M8d50EDHzzehu5CFEqZMqX3";
//	public static final String S3_BUCKET_NAME_PDF = "mmm-bureau-docs";
//	public static final String S3_BUCKET_NAME_LOGS = "mmm-web-app-logs";
//	public static final String PDF_FILE_PATH =  "D:/Document/Dummy/pdfFiles";
//	public static final String LOG_FILE_PATH = "D:/Document/Dummy/pdfFiles";
}
