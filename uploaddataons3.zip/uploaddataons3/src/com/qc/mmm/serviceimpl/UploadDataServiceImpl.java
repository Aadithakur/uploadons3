package com.qc.mmm.serviceimpl;

import java.io.File;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.qc.mmm.service.UploadDataService;
import com.qc.mmm.utils.Constants;

public class UploadDataServiceImpl implements UploadDataService{ 

	@Override
	public boolean uploadFileToS3() {
		
		System.out.println("Upload File Starts ... ");
		Regions clientRegion = Regions.DEFAULT_REGION;
		boolean uploadStatus = false;
        try {
        	AWSCredentials credentials = new BasicAWSCredentials(
        			Constants.ACCESS_KEY, 
        			Constants.SECRET_ACCESS_KEY);
            
            AmazonS3 s3Client = new AmazonS3Client(credentials);
            
            
            File pdfFilefolder = new File(Constants.PDF_FILE_PATH);
            File logFileFolder = new File(Constants.LOG_FILE_PATH);
            
            File[] listOfpdfFiles = pdfFilefolder.listFiles();
            File[] listOflogFiles = logFileFolder.listFiles();
            
            uploadPdfOrLogFile(s3Client, listOfpdfFiles, Constants.S3_BUCKET_NAME_PDF);
            uploadPdfOrLogFile(s3Client, listOflogFiles, Constants.S3_BUCKET_NAME_LOGS);

            uploadStatus = true;
            System.out.println("Upload File Ends ... ");
            
        } catch (Exception ex) {
        	System.out.println("Exception while uploading file :: "+ex.getMessage());
        	uploadStatus = false;
        } 
		return uploadStatus;
	}
	
	private void uploadPdfOrLogFile(AmazonS3 s3Client, File[] listOfpdfOrLogFiles, String s3BucketName) {
		String key = "";
		try {
			for (File file : listOfpdfOrLogFiles) {
	             if (file.isFile()) {
	             	key = file.getName();
	                System.out.println("Key to be used is :: "+key);
	     			s3Client.putObject(s3BucketName,key,file);
	             }
	         }
			 System.out.println("Succesfully uploaded to S3");
		}
		catch(Exception ex) {
			System.out.println("Exception while executing uploadPdfOrLogFile :: "+ex.getMessage());
		}
		 
	}
}
