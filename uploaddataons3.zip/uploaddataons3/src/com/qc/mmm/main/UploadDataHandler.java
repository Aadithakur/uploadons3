package com.qc.mmm.main;

import com.qc.mmm.service.UploadDataService;
import com.qc.mmm.serviceimpl.UploadDataServiceImpl;

public class UploadDataHandler {
	
	public static void main(String[] args) {
		
		UploadDataService uploadDataService = new UploadDataServiceImpl();
		boolean status = uploadDataService.uploadFileToS3();
		System.out.println("Final upload status is :: "+status);
	}

}
