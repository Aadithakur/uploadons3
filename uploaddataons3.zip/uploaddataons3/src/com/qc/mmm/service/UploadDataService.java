package com.qc.mmm.service;


public interface UploadDataService {
	public boolean uploadFileToS3();
}
